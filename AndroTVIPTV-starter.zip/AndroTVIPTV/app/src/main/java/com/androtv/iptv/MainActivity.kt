package com.androtv.iptv

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class StreamItem(val name: String, val url: String, val group: String)

class MainActivity : Activity() {
    private val bg = Color.rgb(16,16,20); private val panel = Color.rgb(35,35,43); private val red = Color.rgb(229,9,20)
    private lateinit var source: EditText; private lateinit var username: EditText; private lateinit var password: EditText
    private lateinit var status: TextView; private lateinit var list: ListView; private lateinit var playerView: PlayerView
    private var player: ExoPlayer? = null
    private val items = mutableListOf<StreamItem>(); private val favorites = mutableSetOf<String>(); private var favMode = false

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=bg; window.navigationBarColor=bg; makeUi() }
    private fun makeUi() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,18,20,16); setBackgroundColor(bg) }
        root.addView(TextView(this).apply { text="ANDROTV  •  IPTV"; textSize=26f; setTextColor(red); setTypeface(null, android.graphics.Typeface.BOLD) })
        source = edit("M3U URL veya Xtream sunucu adresi")
        username = edit("Xtream kullanıcı adı")
        password = edit("Xtream şifresi").apply { inputType=129 }
        root.addView(source, rowParams()); root.addView(username,rowParams()); root.addView(password,rowParams())
        val buttons=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        buttons.addView(button("M3U Yükle",red){loadM3u()},weightParams()); buttons.addView(button("Xtream Yükle",panel){loadXtream()},weightParams()); buttons.addView(button("Favoriler",panel){favMode=!favMode; refresh()},weightParams())
        root.addView(buttons)
        status=TextView(this).apply { text="M3U URL'si veya Xtream bilgilerini girin."; setTextColor(Color.LTGRAY); textSize=14f; setPadding(4,8,4,8) }; root.addView(status)
        val content=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        list=ListView(this).apply {
            setBackgroundColor(panel)
            onItemClickListener=AdapterView.OnItemClickListener { _,_,position,_ -> visibleItems().getOrNull(position)?.let { play(it) } }
            setOnItemLongClickListener { _,_,position,_ -> visibleItems().getOrNull(position)?.let { if(!favorites.add(it.url)) favorites.remove(it.url); refresh() }; true }
        }
        playerView=PlayerView(this).apply { setBackgroundColor(Color.BLACK); useController=true }
        content.addView(list,LinearLayout.LayoutParams(0,0,1f)); content.addView(playerView,LinearLayout.LayoutParams(0,0,1.25f)); root.addView(content,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }
    private fun edit(h: String)=EditText(this).apply { hint=h; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE); textSize=15f; setSingleLine(true); setPadding(10,4,10,4); background=android.graphics.drawable.GradientDrawable().apply { setColor(panel); cornerRadius=10f } }
    private fun rowParams()=LinearLayout.LayoutParams(-1,52).apply { bottomMargin=5 }
    private fun weightParams()=LinearLayout.LayoutParams(0,52,1f).apply { marginEnd=5 }
    private fun button(t:String,c:Int,action:()->Unit)=Button(this).apply { text=t; isAllCaps=false; setTextColor(Color.WHITE); backgroundTintList=android.content.res.ColorStateList.valueOf(c); setOnClickListener{action()} }
    private fun getText(url:String):String { val c=URL(url).openConnection() as HttpURLConnection; c.connectTimeout=15000; c.readTimeout=20000; c.setRequestProperty("User-Agent","AndroTVIPTV/1.0"); try { if(c.responseCode !in 200..299) error("HTTP ${c.responseCode}"); return c.inputStream.bufferedReader().use{it.readText()} } finally { c.disconnect() } }
    private fun loadM3u() {
        val url=source.text.toString().trim(); if(url.isBlank()){status.text="M3U URL'si girin.";return}; status.text="Liste yükleniyor…"
        lifecycleScope.launch { try { val result=withContext(Dispatchers.IO){ parseM3u(getText(url)) }; items.clear(); items.addAll(result); favMode=false; refresh(); status.text="${items.size} içerik yüklendi. Oynatmak için seçin; favori için uzun basın." } catch(e:Exception){status.text="Yükleme başarısız: ${e.message}"} }
    }
    private fun parseM3u(text:String):List<StreamItem> { val out=mutableListOf<StreamItem>(); var name=""; var group="Tümü"; for(raw in text.lineSequence()){val line=raw.trim(); when { line.startsWith("#EXTINF",true)->{name=line.substringAfterLast(',').trim().ifBlank{"İsimsiz içerik"}; group=Regex("""group-title=[\"']([^\"']+)[\"']""",RegexOption.IGNORE_CASE).find(line)?.groupValues?.get(1)?:"Tümü"}; line.startsWith("http://")||line.startsWith("https://")-> {out.add(StreamItem(name.ifBlank{line},line,group));name="";group="Tümü"} } }; return out }
    private fun loadXtream() {
        val base=source.text.toString().trim().trimEnd('/'); val u=username.text.toString().trim(); val p=password.text.toString()
        if(base.isBlank()||u.isBlank()||p.isBlank()){status.text="Sunucu, kullanıcı adı ve şifre gerekli.";return}; status.text="Xtream kataloğu yükleniyor…"
        lifecycleScope.launch { try { val result=withContext(Dispatchers.IO){ val auth="$base/player_api.php?username=${enc(u)}&password=${enc(p)}"; val json=JSONObject(getText(auth)); if(json.optJSONObject("user_info")?.optString("auth")=="0") error("Giriş bilgileri geçersiz")
            val out=mutableListOf<StreamItem>(); val live=JSONObject(getText("$auth&action=get_live_streams")).optJSONArray("streams"); if(live!=null) for(i in 0 until live.length()){val o=live.getJSONObject(i);val id=o.optString("stream_id");val ext=o.optString("container_extension","ts").ifBlank{"ts"};out.add(StreamItem(o.optString("name","Canlı kanal"),"$base/live/${enc(u)}/${enc(p)}/$id.$ext","Canlı TV"))}
            val vod=JSONObject(getText("$auth&action=get_vod_streams")).optJSONArray("streams"); if(vod!=null) for(i in 0 until vod.length()){val o=vod.getJSONObject(i);val id=o.optString("stream_id");val ext=o.optString("container_extension","mp4").ifBlank{"mp4"};out.add(StreamItem(o.optString("name","Film"),"$base/movie/${enc(u)}/${enc(p)}/$id.$ext","Filmler"))};out
        }; items.clear();items.addAll(result);favMode=false;refresh();status.text="${items.size} canlı kanal/film yüklendi. Dizi bölümleri bu başlangıç sürümünde yok." } catch(e:Exception){status.text="Xtream hatası: ${e.message}"} }
    }
    private fun enc(s:String)=URLEncoder.encode(s,"UTF-8")
    private fun visibleItems()=if(favMode) items.filter{favorites.contains(it.url)} else items
    private fun refresh(){ val shown=visibleItems(); list.adapter=object: ArrayAdapter<StreamItem>(this,android.R.layout.simple_list_item_2,android.R.id.text1,shown){ override fun getView(position:Int,convertView:android.view.View?,parent:ViewGroup):android.view.View { val v=super.getView(position,convertView,parent); val a=v.findViewById<TextView>(android.R.id.text1); val b=v.findViewById<TextView>(android.R.id.text2); a.setTextColor(Color.WHITE);a.textSize=16f;b.setTextColor(Color.LTGRAY);b.text="${shown[position].group}  •  ${if(favorites.contains(shown[position].url)) "★ Favori" else "Uzun bas: favori"}";v.setBackgroundColor(panel);return v } } }
    private fun play(item:StreamItem){try{if(player==null){player=ExoPlayer.Builder(this).build();playerView.player=player;player?.addListener(object:Player.Listener{override fun onPlayerError(error:androidx.media3.common.PlaybackException){status.text="Oynatma hatası: ${error.errorCodeName}"}})};player?.setMediaItem(MediaItem.fromUri(item.url));player?.prepare();player?.playWhenReady=true;status.text="Oynatılıyor: ${item.name}"}catch(e:Exception){status.text="Oynatılamadı: ${e.message}"}}
    override fun onDestroy(){player?.release();player=null;super.onDestroy()}
}
