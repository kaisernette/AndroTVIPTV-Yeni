# AndroTV IPTV — kaynak proje

Android TV için koyu temalı temel IPTV uygulaması. M3U/M3U8 listesi yükleme, Xtream Codes üzerinden canlı TV/film kataloğu, ExoPlayer ile oynatma ve oturum içi favoriler içerir. Dizi sezon/bölüm arayüzü ve kalıcı favori kaydı bu ilk sürümde henüz tamamlanmamıştır.

## Telefonda GitHub ile APK oluşturma
1. ZIP'i çıkarın ve içindeki tüm dosyaları GitHub deposunun köküne yükleyin. `.github/workflows/android-apk.yml` dosyası da dahil olmalı.
2. Actions sekmesinde **Build AndroTV IPTV APK** iş akışını çalıştırın.
3. Başarılı çalıştırmanın Artifacts bölümünden `AndroTVIPTV-debug-apk` dosyasını indirin; ZIP'i çıkarın ve `app-debug.apk` dosyasını Android TV'ye aktarın.

APK bu ZIP'in içinde hazır bulunmaz; GitHub Actions bulutta derler. Yalnızca kullanma hakkınız olan yayınları ekleyin. Gerçek Xtream parolalarınızı GitHub koduna koymayın.
